"""PEP-396 compliant package version"""
__version__ = '0.10.0'
